=== Increase Max  Upload Filesize ===
Contributors: Ashutosh Kumar
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=awesomeworks1%40gmail%2ecom&lc=US&item_name=developer%20fund&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHostedGuest
Tags: upload max filesize, increase filesize, upload_max_filesize, post max size, upload limit, upload file size up to 250Mb,php.ini, php5.ini, .user.ini
Requires at least: 3.0.1
Tested up to: 4.8.1
Stable tag: 1.2
Increase upload size limit up to 250Mb and more



== Description==
This plugin increase upload size limit up to 250Mb and more

Very Lightweight- Only 2KB

Installation very easy, just install & enjoy.

Any problem, Please Check FAQ Tab.

Created By: http://www.webitmart.com


== Installation ==

= Automatic =

* In the admin panel under plugins page, click Add New
* go to Upload tab
* browse "upload_max_file_size" and click install now
* Click Active plugin
* Increase File size size by click on Max File Size menu on the left hand side
* Click on max_file_size and then enter the value in bytes Like: 262144000 bytes or 262144000 (You can Enter more value how much you want)
* Example:(Like: 262144000 bytes = 250MB)
* Enjoy!

= Manual =

* Extract zip file to your wp-content/plugins directory.
* In the admin panel under plugins, activate "upload_max_file_size".
* Enjoy!


== Frequently Asked Questions ==
This plugin increase upload size limit up to 250Mb and more.


Any problem, just mail us. email- looklikeme05@gmail.com  ,ashutosh2432@gmail.com